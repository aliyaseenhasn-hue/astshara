---
name: Ethical Juris
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f7'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#191c1e'
  on-surface-variant: '#44474e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f4'
  outline: '#75777f'
  outline-variant: '#c5c6cf'
  surface-tint: '#4e5e82'
  primary: '#031636'
  on-primary: '#ffffff'
  primary-container: '#1a2b4c'
  on-primary-container: '#8293ba'
  inverse-primary: '#b6c6f0'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#11181d'
  on-tertiary: '#ffffff'
  tertiary-container: '#262c32'
  on-tertiary-container: '#8d939b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#b6c6f0'
  on-primary-fixed: '#071b3b'
  on-primary-fixed-variant: '#364669'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#dde3eb'
  tertiary-fixed-dim: '#c1c7cf'
  on-tertiary-fixed: '#161c22'
  on-tertiary-fixed-variant: '#41474e'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e6'
typography:
  display-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  container-max: 1200px
  gutter: 20px
---

## Brand & Style
The design system is engineered to project an aura of unwavering authority, security, and professional excellence tailored for the Iraqi legal landscape. It prioritizes clarity and institutional trust, ensuring users feel protected and well-advised at every touchpoint.

The aesthetic follows a **Corporate / Modern** approach with a focus on precision. It leverages a structured grid, generous whitespace to reduce cognitive load during stressful legal situations, and a sophisticated interplay between deep prestige tones and illuminating accents. The visual language is intentionally "stable"—avoiding trendy flourishes in favor of a timeless, reliable interface that respects the gravity of legal consultation.

## Colors
The palette is rooted in **Deep Navy Blue**, representing the stability and depth of the law. **Gold** is used surgically as a high-value accent for Call-to-Action elements and premium indicators, suggesting quality and specialized expertise.

- **Primary (Navy):** Used for headers, navigation, and primary button backgrounds to establish authority.
- **Secondary (Gold):** Used for critical conversion points, active states, and highlighting "Verified" statuses.
- **Background (Light Gray):** Provides a clean, paper-like canvas that reduces eye strain.
- **Semantic Colors:** Muted versions of green, red, and amber are used for payment and case statuses, ensuring they remain professional rather than alarming.

## Typography
This design system utilizes **IBM Plex Sans Arabic** for its exceptional legibility in both Arabic and Latin scripts, maintaining a technical yet approachable feel. 

- **Hierarchy:** Use Bold weights for law firm names and section headers to anchor the page. 
- **Readability:** Body text uses a 1.5x line-height ratio to ensure legal descriptions and terms of service are easily digestible.
- **Alignment:** Given the primary user base, the layout must prioritize Right-to-Left (RTL) reading patterns, ensuring that type weights support the visual density of Arabic characters.

## Layout & Spacing
The layout follows a **Fixed Grid** system for desktop (12 columns) and a fluid 4-column system for mobile. 

- **Vertical Rhythm:** An 8px base unit governs all dimensions.
- **Margins:** Mobile screens maintain a 20px outer margin to prevent content from feeling cramped.
- **Desktop:** Content is centered in a 1200px container to maintain an authoritative, editorial feel. 
- **Grouping:** Use `spacing-md` to separate distinct lawyer cards and `spacing-sm` for internal card padding.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. This design avoids floating elements; instead, it uses subtle elevation to define hierarchy.

- **Level 0 (Background):** #F5F7FA.
- **Level 1 (Cards):** White (#FFFFFF) with a very soft, diffused shadow (0px 4px 12px rgba(26, 43, 76, 0.05)).
- **Level 2 (Interaction):** When hovering or selecting a consultation type, the shadow intensifies slightly (0px 8px 20px rgba(26, 43, 76, 0.10)) to provide tactile feedback.
- **Inlays:** Search inputs and selection fields use a 1px border (#E2E8F0) rather than a shadow, keeping the interface grounded and crisp.

## Shapes
The design system employs a **Soft** shape language. 

- **Standard Elements:** Buttons and input fields use a 4px (0.25rem) corner radius. This maintains a professional, "sharp" look while being modern.
- **Containers:** Lawyer profile cards and large modals use `rounded-lg` (8px) to soften the overall presentation of the app without appearing overly casual.
- **Badges:** Status indicators (e.g., "Paid", "Pending") use a slightly higher radius to distinguish them from functional buttons.

## Components

### Search & Navigation
- **Search Bar:** Full-width container with a persistent search icon on the right (for RTL). Use a placeholder like "Search by specialty or lawyer name..." in a muted gray.
- **Consultation Selectors:** Use segmented controls for Text/Call/Video. The active state is indicated by the Primary Navy color with white text.

### Cards & Lists
- **Lawyer Profile Cards:** High-contrast White backgrounds. The lawyer's name is in `title-lg` Navy. Include a Gold-tinted star rating and a "Verified" badge using the Secondary Gold.
- **Consultation Cards:** Include a clear timestamp and a "Join Session" CTA button in Gold.

### Feedback & Status
- **Payment Status Badges:** Small, pill-shaped indicators.
    - *Paid:* Light green background with dark green text.
    - *Pending:* Light amber background with dark amber text.
- **Input Fields:** 1px border. On focus, the border transitions to Primary Navy with a 2px thickness.

### Buttons
- **Primary CTA:** Deep Navy background, White text.
- **Secondary/Premium CTA:** Gold background, Navy text (used for "Book Appointment").
- **Ghost Buttons:** Navy border and text, transparent background (used for "View Profile").